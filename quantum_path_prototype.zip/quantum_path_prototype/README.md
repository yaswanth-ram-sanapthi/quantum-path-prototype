# Quantum Path Planning Prototype (Hybrid: Classical + Quantum)

This is a working prototype for **Amaravati Quantum Valley Hackathon 2025 – Quantum Path Planning for Delivery Vehicles (Fleet Optimization)**.

The prototype provides:
- **Classical VRP solver** using Google **OR-Tools** (baseline, scalable).
- **Quantum (QAOA) TSP demo** with **Qiskit** for **small instances** (5–10 nodes).
- **Hybrid pipeline** that compares distance/cost and runtime.
- **Streamlit UI** for interactive demos and a **Folium** map for route visualization.

> ⚠️ Quantum part is intended for demonstration on small instances only. Use the classical solver for realistic sizes.

---

## 1) Quick Start

### Option A – Streamlit App (recommended for demo)
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt

streamlit run src/app_streamlit.py
```
Open the local URL shown in the terminal.

### Option B – CLI
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# Run classical VRP on sample data
python src/hybrid_pipeline.py --solver classical --csv data/sample_locations.csv

# Run quantum TSP (QAOA) demo on first N nodes (small!)
python src/hybrid_pipeline.py --solver quantum --csv data/sample_locations.csv --nodes 7

# Compare both
python src/hybrid_pipeline.py --solver hybrid --csv data/sample_locations.csv --nodes 7
```

Outputs:
- A route summary in the console
- A map saved to `outputs/route_map.html`

---

## 2) Data Format

CSV columns (sample in `data/sample_locations.csv`):
```
name,lat,lon,demand,ready_time,due_time,service_time
Depot,16.5062,80.6480,0,0,1000,0
Customer A,16.5180,80.6290,1,0,1000,0
Customer B,16.5150,80.6390,1,0,1000,0
...
```
- **lat, lon:** coordinates (WGS84)
- **demand:** units to deliver (use 0–1 for demo)
- **ready_time/due_time/service_time:** basic time window support for VRP (can keep 0 and large numbers if not used).

---

## 3) Architecture

- `src/classical_solver.py` – OR-Tools VRP with capacity & optional time windows.
- `src/quantum_qaoa_tsp.py` – QAOA-based TSP solver (Qiskit) for small N.
- `src/visualize.py` – Folium map drawing.
- `src/hybrid_pipeline.py` – Command-line orchestration & comparison.
- `src/app_streamlit.py` – Streamlit UI for demos.

---

## 4) Notes for the Hackathon Pitch

- Show **classical baseline** on 20–50 nodes (fast, reliable).
- Show **quantum demo** on 6–10 nodes (educational value; talk about QUBO/Ising, mixers, p-levels).
- Present **hybrid story**: use OR-Tools for larger scale, and QAOA for constraint exploration or as a heuristic seed; emphasize **future scaling** as quantum hardware improves.
- Highlight **impact**: time/fuel savings, CO₂ reduction, real-time adaptation (can mock real-time update by changing 1–2 nodes and re-solving).

---

## 5) License
MIT
