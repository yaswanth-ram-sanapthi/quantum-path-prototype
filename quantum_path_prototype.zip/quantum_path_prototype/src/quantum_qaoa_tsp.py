\
"""
QAOA TSP demo using Qiskit Optimization.
Only for small N (e.g., 6-10) due to exponential overhead in classical preprocessing.
"""
import time
import numpy as np
import pandas as pd
from typing import Dict, Any, List, Tuple

from qiskit_optimization import QuadraticProgram
from qiskit_optimization.algorithms import MinimumEigenOptimizer
from qiskit_algorithms import QAOA
from qiskit.primitives import Estimator
from qiskit.circuit.library import TwoLocal
from qiskit_algorithms.optimizers import COBYLA

from math import radians, sin, cos, asin, sqrt

EARTH_R = 6371.0
def haversine_km(a, b):
    lat1, lon1 = radians(a[0]), radians(a[1])
    lat2, lon2 = radians(b[0]), b[1] * np.pi/180.0
    dlat = lat2 - lat1
    dlon = (b[1] - a[1]) * np.pi/180.0
    h = (np.sin(dlat/2)**2 +
         np.cos(lat1)*np.cos(lat2)*np.sin(dlon/2)**2)
    return 2 * EARTH_R * np.arcsin(np.sqrt(h))

def distance_matrix(coords: List[Tuple[float,float]]) -> np.ndarray:
    n = len(coords)
    D = np.zeros((n,n))
    for i in range(n):
        for j in range(n):
            if i == j:
                continue
            D[i,j] = haversine_km(coords[i], coords[j])
    return D

def tsp_qubo_qaoa(coords: List[Tuple[float,float]], p: int = 1) -> Dict[str, Any]:
    n = len(coords)
    D = distance_matrix(coords)

    qp = QuadraticProgram()
    # binary variables x_{i,j}: city i at position j
    for i in range(n):
        for j in range(n):
            qp.binary_var(name=f"x_{i}_{j}")

    # Each city appears exactly once
    for i in range(n):
        qp.linear_constraint(
            linear={f"x_{i}_{j}": 1 for j in range(n)},
            sense="==",
            rhs=1,
            name=f"city_once_{i}"
        )

    # Each position is occupied by exactly one city
    for j in range(n):
        qp.linear_constraint(
            linear={f"x_{i}_{j}": 1 for i in range(n)},
            sense="==",
            rhs=1,
            name=f"pos_once_{j}"
        )

    # Objective: sum of distances between consecutive positions
    obj = {}
    for i in range(n):
        for j in range(n):
            for k in range(n):
                if j != k:
                    next_pos = (k == (j+1) % n)
                    if next_pos:
                        # penalize distance from city i at pos j to city h at pos j+1
                        for h in range(n):
                            if h != i:
                                obj[(f"x_{i}_{j}", f"x_{h}_{(j+1)%n}")] = D[i, h]

    qp.minimize(quadratic=obj, linear={})

    # QAOA setup
    estimator = Estimator()
    qaoa = QAOA(estimator=estimator, reps=p, optimizer=COBYLA(maxiter=100))
    opt = MinimumEigenOptimizer(qaoa)

    t0 = time.time()
    result = opt.solve(qp)
    t1 = time.time()

    # Decode solution
    x = result.x
    order = [-1]*n
    for i in range(n):
        for j in range(n):
            if int(round(x[i*n + j])) == 1:
                order[j] = i

    # route indices from depot 0
    route = [order[0]]
    for j in range(1, n):
        route.append(order[j])
    route.append(order[0])  # return

    total_km = 0.0
    for a, b in zip(route[:-1], route[1:]):
        total_km += D[a, b]

    return {
        "route": route,
        "distance_km": float(total_km),
        "runtime_s": t1 - t0,
    }
