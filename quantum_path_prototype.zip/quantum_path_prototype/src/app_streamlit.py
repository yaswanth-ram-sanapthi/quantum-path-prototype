\
import streamlit as st
import pandas as pd
import tempfile, os
from classical_solver import solve_vrp
from visualize import plot_route_map

st.set_page_config(page_title="Quantum Path Planning – Hybrid Demo", layout="wide")
st.title("🚚 Quantum Path Planning – Hybrid (Classical + Quantum)")

st.markdown("""
**How to use**
1. Upload a CSV (or use the sample).
2. Choose solver: **Classical (VRP)** or **Quantum (QAOA TSP demo)** or **Hybrid**.
3. View route summary and interactive map.
""")

uploaded = st.file_uploader("Upload CSV with columns: name,lat,lon,demand,ready_time,due_time,service_time", type=["csv"])
use_sample = st.checkbox("Use sample dataset", value=True)

if uploaded and not use_sample:
    df = pd.read_csv(uploaded)
else:
    df = pd.read_csv("data/sample_locations.csv")

st.subheader("Preview Data")
st.dataframe(df)

solver = st.selectbox("Choose solver", ["Classical (VRP)", "Quantum (QAOA TSP demo)", "Hybrid (compare on small subset)"])

if st.button("Run"):
    with st.spinner("Solving..."):
        if "Quantum" in solver:
            try:
                from quantum_qaoa_tsp import tsp_qubo_qaoa
            except Exception as e:
                st.error("Quantum modules not installed. Please install qiskit and qiskit-optimization.")
                st.stop()

        if solver.startswith("Classical"):
            res = solve_vrp("data/sample_locations.csv" if use_sample else uploaded, vehicle_count=2, vehicle_capacity=3, time_windows=False)
            route = res["routes"][0]
            coords = res["coords"]
            names = res["node_names"]
            st.success(f"Total distance (all vehicles): {res['distance_m']/1000:.2f} km")
            out = plot_route_map(coords, route, "outputs/route_map.html")
            st.markdown(f"[Open route map]({out})", unsafe_allow_html=True)

        elif solver.startswith("Quantum"):
            df_small = df.iloc[:st.number_input("Nodes for quantum demo", 5, len(df), 7)]
            coords = list(zip(df_small['lat'], df_small['lon']))
            names = df_small['name'].tolist()
            res = tsp_qubo_qaoa(coords, p=1)
            st.success(f"Distance: {res['distance_km']:.2f} km | Runtime: {res['runtime_s']:.2f}s")
            out = plot_route_map(coords, res["route"], "outputs/route_map_quantum.html")
            st.markdown(f"[Open route map]({out})", unsafe_allow_html=True)

        else:
            from quantum_qaoa_tsp import tsp_qubo_qaoa
            df_small = df.iloc[:st.number_input("Nodes for quantum demo", 5, len(df), 7)]
            coords = list(zip(df_small['lat'], df_small['lon']))

            import tempfile
            with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as tmp:
                df_small.to_csv(tmp.name, index=False)
                tmp_path = tmp.name

            class_res = solve_vrp(tmp_path, vehicle_count=1, vehicle_capacity=999, time_windows=False)
            q_res = tsp_qubo_qaoa(coords, p=1)
            st.write("**Classical distance (km):**", class_res["distance_m"]/1000.0)
            st.write("**Quantum distance (km):**", q_res["distance_km"])
            out1 = plot_route_map(class_res["coords"], class_res["routes"][0], "outputs/route_map_classical.html")
            out2 = plot_route_map(coords, q_res["route"], "outputs/route_map_quantum.html")
            st.markdown(f"[Open classical map]({out1}) | [Open quantum map]({out2})", unsafe_allow_html=True)

st.caption("© 2025 Code Squashers – MIT License")
