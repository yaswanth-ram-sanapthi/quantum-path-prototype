\
import math
import pandas as pd
import numpy as np
from typing import Dict, List, Tuple
from ortools.constraint_solver import pywrapcp, routing_enums_pb2

EARTH_R = 6371.0

def haversine_km(a, b):
    lat1, lon1 = math.radians(a[0]), math.radians(a[1])
    lat2, lon2 = math.radians(b[0]), math.radians(b[1])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    h = (math.sin(dlat/2)**2 +
         math.cos(lat1)*math.cos(lat2)*math.sin(dlon/2)**2)
    return 2 * EARTH_R * math.asin(math.sqrt(h))

def build_distance_matrix(coords: List[Tuple[float, float]]) -> List[List[int]]:
    n = len(coords)
    dist = [[0]*n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            if i == j:
                continue
            dist[i][j] = int(haversine_km(coords[i], coords[j]) * 1000)  # meters
    return dist

def solve_vrp(csv_path: str,
              vehicle_count: int = 2,
              vehicle_capacity: int = 3,
              time_windows: bool = False):
    df = pd.read_csv(csv_path)
    coords = list(zip(df['lat'].tolist(), df['lon'].tolist()))
    demands = df['demand'].fillna(0).astype(int).tolist()

    distance_matrix = build_distance_matrix(coords)

    manager = pywrapcp.RoutingIndexManager(len(distance_matrix), vehicle_count, 0)  # depot=0
    routing = pywrapcp.RoutingModel(manager)

    def distance_callback(from_index, to_index):
        f, t = manager.IndexToNode(from_index), manager.IndexToNode(to_index)
        return distance_matrix[f][t]

    transit_callback_index = routing.RegisterTransitCallback(distance_callback)
    routing.SetArcCostEvaluatorOfAllVehicles(transit_callback_index)

    # Capacity
    def demand_callback(from_index):
        node = manager.IndexToNode(from_index)
        return int(demands[node])
    demand_callback_index = routing.RegisterUnaryTransitCallback(demand_callback)
    routing.AddDimensionWithVehicleCapacity(
        demand_callback_index, 0, [vehicle_capacity]*vehicle_count, True, "Capacity"
    )

    # Time windows (optional; simplistic with travel time proportional to distance)
    if time_windows:
        speed_m_per_min = 300.0  # ~18 km/h city assumption for demo
        def time_callback(from_index, to_index):
            f, t = manager.IndexToNode(from_index), manager.IndexToNode(to_index)
            travel_mins = distance_matrix[f][t] / speed_m_per_min
            return int(travel_mins)

        time_cb_idx = routing.RegisterTransitCallback(time_callback)
        routing.AddDimension(time_cb_idx, 30, 24*60, False, "Time")
        time_dim = routing.GetDimensionOrDie("Time")

        ready = df['ready_time'].fillna(0).astype(int).tolist()
        due = df['due_time'].fillna(24*60).astype(int).tolist()
        for node in range(len(coords)):
            idx = manager.NodeToIndex(node)
            time_dim.CumulVar(idx).SetRange(ready[node], due[node])

    search_parameters = pywrapcp.DefaultRoutingSearchParameters()
    search_parameters.solution_limit = 10000
    search_parameters.time_limit.FromSeconds(10)
    search_parameters.first_solution_strategy = routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC
    search_parameters.local_search_metaheuristic = routing_enums_pb2.LocalSearchMetaheuristic.GUIDED_LOCAL_SEARCH

    solution = routing.SolveWithParameters(search_parameters)
    if not solution:
        raise RuntimeError("No solution found by OR-Tools. Try relaxing constraints.")

    total_distance = 0
    routes = []
    for v in range(vehicle_count):
        index = routing.Start(v)
        route_nodes = []
        route_distance = 0
        while not routing.IsEnd(index):
            node = manager.IndexToNode(index)
            route_nodes.append(node)
            prev_index = index
            index = solution.Value(routing.NextVar(index))
            route_distance += routing.GetArcCostForVehicle(prev_index, index, v)
        route_nodes.append(manager.IndexToNode(index))
        routes.append(route_nodes)
        total_distance += route_distance

    return {
        "routes": routes,               # node indices including depot 0
        "distance_m": total_distance,   # sum of all vehicles
        "node_names": df['name'].tolist(),
        "coords": coords,
    }
