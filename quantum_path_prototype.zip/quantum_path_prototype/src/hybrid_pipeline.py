\
import argparse, os, time
import pandas as pd
from typing import List, Tuple
from classical_solver import solve_vrp
from visualize import plot_route_map

def _take_first_n(csv_path: str, n: int):
    df = pd.read_csv(csv_path)
    # ensure depot + first n-1 customers, clip if needed
    n = min(n, len(df))
    return df.iloc[:n].reset_index(drop=True)

def classical(csv_path: str):
    result = solve_vrp(csv_path, vehicle_count=2, vehicle_capacity=3, time_windows=False)
    # choose the longest route to visualize (or flatten any one vehicle)
    # For demo, take first vehicle's route
    route = result["routes"][0]
    coords = result["coords"]
    names = result["node_names"]
    print("Classical VRP (OR-Tools)")
    for i in range(len(route)-1):
        print(f"{names[route[i]]} -> {names[route[i+1]]}")
    print(f"Total distance (all vehicles): {result['distance_m']/1000:.2f} km")
    os.makedirs("outputs", exist_ok=True)
    out_map = plot_route_map(coords, route, "outputs/route_map.html")
    print(f"Map saved to: {out_map}")

def quantum(csv_path: str, nodes: int = 7):
    # Small TSP demo via QAOA
    from quantum_qaoa_tsp import tsp_qubo_qaoa
    df = _take_first_n(csv_path, nodes)
    coords = list(zip(df['lat'], df['lon']))
    names = df['name'].tolist()
    print("Quantum TSP (QAOA) demo on first", len(coords), "nodes")
    res = tsp_qubo_qaoa(coords, p=1)
    route = res["route"]
    print("Route (indices):", route)
    print("Route (names):", " -> ".join(names[i] for i in route))
    print(f"Distance: {res['distance_km']:.2f} km | Runtime: {res['runtime_s']:.2f}s")
    os.makedirs("outputs", exist_ok=True)
    out_map = plot_route_map(coords, route, "outputs/route_map.html")
    print(f"Map saved to: {out_map}")

def hybrid(csv_path: str, nodes: int = 7):
    # Compare classical vs quantum on the same small subset
    from quantum_qaoa_tsp import tsp_qubo_qaoa
    df_small = _take_first_n(csv_path, nodes)
    coords_small = list(zip(df_small['lat'], df_small['lon']))
    names_small = df_small['name'].tolist()

    # Classical baseline on small subset (force 1 vehicle to mimic TSP)
    from classical_solver import solve_vrp
    res_class = solve_vrp(df_small.to_csv(index=False), vehicle_count=1, vehicle_capacity=999, time_windows=False)
    # The call above expects a path; write temp
    import tempfile
    with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as tmp:
        df_small.to_csv(tmp.name, index=False)
        tmp_path = tmp.name
    res_class = solve_vrp(tmp_path, vehicle_count=1, vehicle_capacity=999, time_windows=False)

    route_class = res_class["routes"][0]
    dist_class_km = res_class["distance_m"]/1000.0

    # Quantum
    res_quant = tsp_qubo_qaoa(coords_small, p=1)

    print("=== Hybrid Comparison (subset) ===")
    print("Classical distance (km):", f"{dist_class_km:.2f}")
    print("Quantum distance (km):", f"{res_quant['distance_km']:.2f}")
    print("Quantum runtime (s):", f"{res_quant['runtime_s']:.2f}")
    os.makedirs("outputs", exist_ok=True)
    plot_route_map(coords_small, res_quant["route"], "outputs/route_map_quantum.html")
    plot_route_map(res_class["coords"], route_class, "outputs/route_map_classical.html")
    print("Maps saved to outputs/*.html")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--solver", choices=["classical", "quantum", "hybrid"], required=True)
    parser.add_argument("--csv", type=str, default="data/sample_locations.csv")
    parser.add_argument("--nodes", type=int, default=7, help="nodes for quantum demo")
    args = parser.parse_args()

    if args.solver == "classical":
        classical(args.csv)
    elif args.solver == "quantum":
        quantum(args.csv, args.nodes)
    else:
        hybrid(args.csv, args.nodes)
