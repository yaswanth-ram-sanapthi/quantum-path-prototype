\
import folium
from typing import List, Tuple

def plot_route_map(coords: List[Tuple[float,float]], route: List[int], out_html: str):
    # center map
    lat = sum([c[0] for c in coords]) / len(coords)
    lon = sum([c[1] for c in coords]) / len(coords)
    m = folium.Map(location=[lat, lon], zoom_start=13)

    # plot markers
    for idx, (la, lo) in enumerate(coords):
        color = "red" if idx == 0 else "blue"
        folium.Marker([la, lo], popup=f"Node {idx}", tooltip=f"{idx}", icon=folium.Icon(color=color)).add_to(m)

    # polyline
    path = [(coords[i][0], coords[i][1]) for i in route]
    folium.PolyLine(path, weight=5).add_to(m)

    m.save(out_html)
    return out_html
